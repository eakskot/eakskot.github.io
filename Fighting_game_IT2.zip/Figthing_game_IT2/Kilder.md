# Python-Platformer
Kilder: 

Grunnlegg for spill: https://youtu.be/B6DrRN5z_uU

Skyte-lyd: https://youtu.be/LIFFq5ar4fg 

Bakgrunn sang: https://www.youtube.com/watch?v=uhalchtIIt4

