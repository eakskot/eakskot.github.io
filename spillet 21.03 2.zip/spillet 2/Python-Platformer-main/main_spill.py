#Emil, Vegard og Ola

import os
import random
import math
import pygame as pg
from os import listdir
from os.path import isfile, join



pg.init()
pg.mixer.init()

pg.mixer.music.load(join("assets", "Sound","backgroundMusic.mp3"))
pg.mixer.music.play(-1,0.0)


jumpingSound=pg.mixer.Sound(join( "assets", "Sound", "Jumping_sound.wav"))

pg.display.set_caption("Platformer")


#konstanter
WIDTH= 1200
HEIGHT= 700
FPS= 60
PLAYER_VEL= 5


bullets = []
bullets2 = []


window= pg.display.set_mode((WIDTH, HEIGHT))

def flip(sprites):
    return [pg.transform.flip(sprite, True, False) for sprite in sprites] #sjekker om man skal snu bilde i høyre eller venstre




def load_sprite_sheets(dir1, dir2, width, height, direction=False):
    path = join("assets", dir1, dir2) #fra os
    images = [f for f in listdir(path) if isfile(join(path, f))]

    all_sprites = {}

    for image in images: #får alle individuelle bilder i filen
        sprite_sheet = pg.image.load(join(path, image)).convert_alpha() #kan bruke trasnparent bilder

        sprites = []
        for i in range(sprite_sheet.get_width() // width):
            surface = pg.Surface((width, height), pg.SRCALPHA, 32) #lager en surface som er samme str som i 32 pixler

            rect = pg.Rect(i * width, 0, width, height)
            surface.blit(sprite_sheet, (0, 0), rect) #blir betyr draw
            sprites.append(pg.transform.scale2x(surface)) #scaler de 2x

        if direction: #Lager to versioner av hvert bilde. En mot høyre og en mot venstre
            all_sprites[image.replace(".png", "") + "_left"] = sprites #må bytte på disse to
            all_sprites[image.replace(".png", "") + "_right"] = flip(sprites) #
        else:
            all_sprites[image.replace(".png", "")] = sprites

    return all_sprites


def get_block(size):
    path= join("assets", "Terrain", "Terrain.png")
    image= pg.image.load(path).convert_alpha()
    surface= pg.Surface((size, size), pg.SRCALPHA,32)
    rect= pg.Rect(96, 0, size, size) #må justere disse hvis jeg skal ha andre bilder fra Terrain
    surface.blit(image,(0,0), rect)
    
    
    return pg.transform.scale2x(surface) 
    
    



#gjør det lett med pixel-perfect collision med sprite
class Player(pg.sprite.Sprite):
    COLOR= (255,0,0)
    GRAVITY=1
    SPRITES=load_sprite_sheets("MainCharacters", "Ove2", 50, 50, True) #True fordi vi vil ha en multidirectonal sprite
    #henter fra mappen MainCharacters-> Emil
    ANIMATION_DELAY= 10
    
    
    def __init__(self, x, y, width, height, hvem):
        super().__init__()
        self.rect= pg.Rect(x, y, width, height)
        self.x_vel= 0 #hvor fort player beveger seg i hver frame
        self.y_vel= 0
        self.mask= None
        self.direction= "left"
        self.animation_count= 0
        self.fall_count=0
        self.jump_count= 0
        self.hvem = hvem
        self.health= 10
        self.visible= True
        self.hitbox=(self.rect.x+25, self.rect.y, 50, 100)
        
 
      
    def draw(self, win):
        if self.visible == True:
            win.blit(self.sprite, (self.rect.x, self.rect.y))
            self.hitbox=(self.rect.x+25, self.rect.y, 50, 100)
            pg.draw.rect(win, (255, 0 ,0), (self.rect.x+ 20, self.rect.y-20, 50, 10))
            pg.draw.rect(win, (0, 255 ,0), (self.rect.x + 20, self.rect.y-20, 50 - (5 * (10-self.health)), 10))
            
            #pg.draw.rect(win, (255, 0, 0), self.hitbox, 2)
        
    def jump(self):
        self.y_vel = -self.GRAVITY * 8 #lar grvaity dra oss ned
        self.animation_count = 0
        self.jump_count += 1
        if self.jump_count == 1:
            self.fall_count = 0 #gjør at player blir kvitt all tyngdekraft når han hopper
        
        
        
    def move(self,dx,dy):
        self.rect.x+= dx
        self.rect.y+= dy
        
        
    def move_left(self, vel):
        self.x_vel= -vel #subrahere fra x-posisjonen
        if self.direction!= "left":
            self.direction= "left"
            self.animation_count= 0
        
        
    def move_right(self, vel):
        self.x_vel= vel
        #print("halo")
        if self.direction!= "right":
            self.direction= "right"
            self.animation_count= 0
            

            
            
        
    def loop(self, fps): #en frame er en iteration i en hvile loop
        self.y_vel += min(1, (self.fall_count/fps)*self.GRAVITY) #gir realitisk tyngdekraft 
        self.move(self.x_vel, self.y_vel)
        
        self.fall_count+=1
        
        self.update_sprite()
        
    
    def landed(self):
        self.fall_count= 0
        self.y_vel= 0 #his man lander på en block stopper man å bevege seg
        self.jump_count= 0
        
    
        
        
    def hit_head(self):
        self.count= 0
        self.y_vel *=-1 #reveserer vertikal fart så man beveger sge nedover hvis man hitter noe med hodet 
        
        
    def update_sprite(self):
        
        sprite_sheet= f"{self.hvem}_idle" #hentet fra MainCharacters-> Emil
        
       
                            
        if self.y_vel< 0:
            if self.jump_count == 1 and self.animation_count < 5:
                sprite_sheet = f"{self.hvem}_jump"
            elif self.animation_count > 5:
                sprite_sheet = f"{self.hvem}_fall"
          
        elif self.y_vel> self.GRAVITY*2:
            sprite_sheet= f"{self.hvem}_fall"
        

        
        elif self.x_vel!= 0:
            
            sprite_sheet= f"{self.hvem}_run"
            self.ANIMATION_DELAY = 5
        elif self.x_vel == 0:
            self.ANIMATION_DELAY = 10
            
        
        
            
        sprite_sheet_name= sprite_sheet + "_" + self.direction #adder direction til sprite_sheet'et
        sprites= self.SPRITES[sprite_sheet_name]
        sprite_index= (self.animation_count // self.ANIMATION_DELAY) % len(sprites) #hver 5 frames viser vi en annen animation i hver animasjon, og får det til på funke på hver sprite_sheet
        self.sprite= sprites[sprite_index]
        self.animation_count+= 1 #nullstilles ve hver nye bevegelse? 
        self.update()
        
        
        
        
    def update(self):
        self.rect = self.sprite.get_rect(topleft= (self.rect.x, self.rect.y)) #justerer rektangel til spilleren
        self.mask = pg.mask.from_surface(self.sprite) #mapping av alle pixler i en sprite, forteller hvor det faktisk er pixler- kan gjøre pixel-perfect collision
        
    def hit(self):
        if self.health > 0.5:
            self.health -=0.5
        else:
            self.visible = False
        print("hit")
    
        
        
        
class Player2(Player):
    def __init__(self, x, y, width, height):
        super().__init__()
        self.rect= pg.Rect(x, y, width, height)
        self.x_vel= 0 #hvor fort player beveger seg i hver frame
        self.y_vel= 0
        self.mask= None
        self.animation_count= 0
        self.fall_count=0
        self.jump_count= 0
        super().__init__()
        self.direction= "left"
        self.hitbox=(self.rect.x+25, self.rect.y, 50, 100)
        

        

  
        
        
        
class Object(pg.sprite.Sprite):
    def __init__(self, x, y, width, height, name= None):
        super().__init__()
        self.rect= pg.Rect(x,y,width,height) #definerer rect
        self.image= pg.Surface((width, height), pg.SRCALPHA) #transpernt images
        self.width= width
        self.height= height
        self.name= name
        
        
    def draw(self, win):
        win.blit(self.image, (self.rect.x, self.rect.y))
        
        
class Block(Object):
    def __init__(self, x, y, size):
        super().__init__(x, y, size, size)
        block= get_block(size)
        self.image.blit(block, (0,0))
        self.mask= pg.mask.from_surface(self.image) #trenger for kollisjon
        
    
    
        
        


def get_background(name): #bakgrunnen
    
    image = pg.image.load(join ("assets", "Background", name))
    
    _,_, width, height= image.get_rect() #skriver underscore for x og y men trenger ikke de
    tiles= []
    for i in range(WIDTH // width+1):
        for j in range(HEIGHT// height+1):
            pos= (i*width, j*height)
            tiles.append(pos) #fyller skjermen med tiles
            
    return tiles, image 


def draw(window, background, bg_image, player,player2, objects):
    for tile in background:
        window.blit(bg_image, tile) #blitter tiles
        
    for obj in objects:
        obj.draw(window) #tegner på vinduet
        
    for bullet in bullets:
        bullet.draw(window)
    for bullet in bullets2:
        bullet.draw(window)
        
    player.draw(window)
    player2.draw(window)
    
    pg.display.update()
    
    
def handle_vertical_collision(player, objects, dy, dx): #dy= displacement in y
    collided_objects= []
    for obj in objects:
        if pg.sprite.collide_mask(player,obj): #forteller om player collider med object
            if dy > 0:
                player.rect.bottom= obj.rect.top#putte rplayer på toppen av objektet den kolliderer med, hvis kollidere med bakke, gjør players posisjon samme som bakken
                player.landed()
            elif dy<0:
                player.rect.top= obj.rect.bottom
                player.hit_head()
                
        collided_objects.append(obj) #så man vet hva slags objekter man har kollidert med
        
    return collided_objects



def vertikale_kollisjoner_spillere(spiller, spiller2, dy):
    
    if pg.sprite.collide_mask(spiller, spiller2) and spiller.rect.y - spiller2.rect.y < 5:
        spiller.rect.bottom = spiller2.rect.top
        spiller.landed()
        


def collide(player, objects, dx):
    player.move(dx, 0)
    player.update()
    collided_object=None
    for obj in objects: #Sjekker om spilleren vil kollidere med noe hvis den flytter
        if pg.sprite.collide_mask(player, obj):
            collided_object=obj
            break
        
    player.move(-dx, 0)
    player.update() #Flytter tilbake til der vi sto før hvis det er en kollisjon
    return collided_object

def collission(player, player2, dx):
    player.move(dx, 0)
    player.update()
    collided_object=None
    if pg.sprite.collide_mask(player, player2):
        collided_object= player2
        
    player.move(-dx,0)
    player.update()
    return collided_object
    
            
                
def handle_move(player, objects, player2): #håndterer alle bevegelser og kollisjoner osv
    keys= pg.key.get_pressed()
    
    player.x_vel= 0
    collide_left=collide(player, objects, -PLAYER_VEL*6)
    collide_right= collide(player, objects, PLAYER_VEL*6)
    collission_left=collission(player, player2, -PLAYER_VEL*6)
    collission_right=collission(player, player2, PLAYER_VEL*6)
    
    
    
#    player2.x_vel=0
    
    if keys[pg.K_LEFT] and not collide_left and not collission_left and player.hitbox[0]>0: #Hvis venstre piltast blir trykket og spilleren ikke koliderer med noe mot venstre så skal spilleren bevege seg mot venstre.
        player.move_left(PLAYER_VEL)
    
    if keys[pg.K_RIGHT] and not collide_right and not collission_right and player.hitbox[0] + player.hitbox[2] < WIDTH:
        player.move_right(PLAYER_VEL)
        
        
    handle_vertical_collision(player, objects, player.y_vel, 10)
    vertikale_kollisjoner_spillere(player, player2, player.y_vel)
    #handle_vertical_collision(player2, objects, player.y_vel)

def handle_move_player2(player2, objects, player): #håndterer alle bevegelser og kollisjoner osv
    keys= pg.key.get_pressed()
    

    player2.x_vel=0
    collide_left=collide(player2, objects, -PLAYER_VEL*7)
    collide_right= collide(player2, objects, PLAYER_VEL*7)
    collission_left=collission(player2, player, -PLAYER_VEL*7)
    collission_right=collission(player2, player, PLAYER_VEL*7)
    
    if keys[pg.K_a] and not collide_left and not collission_left and player2.hitbox[0] > 0:
        player2.move_left(PLAYER_VEL)
    
    if keys[pg.K_d] and not collide_right and not collission_right and player2.hitbox[0] + player.hitbox[2] < WIDTH:
        player2.move_right(PLAYER_VEL)
        
        
    handle_vertical_collision(player2, objects, player2.y_vel, 10)
    vertikale_kollisjoner_spillere(player2, player, player2.y_vel)


class projectile(object):
    def __init__(self,x,y,radius,color,facing):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.facing = facing
        self.vel = 8 * facing
        
    def draw(self, win):
        pg.draw.circle(win, self.color, (self.x,self.y), self.radius)
    


#styrer al: event-loop
def main(window):
    clock= pg.time.Clock()
    background, bg_image =get_background("YELLOW.png")
    
    block_size= 96
    
    player= Player(600,300,50,50,"o") #x,y,w,h
    player2 = Player(200,300,50,50,"e")
    player2.direction = "right"
    
    floor= [Block(i*block_size, HEIGHT- block_size, block_size) for i in range(-WIDTH*2//block_size, (WIDTH*2)//block_size)] #vil lage blokker som går både venstre og høyre side av skjermen-pga scrolling background
    #hvordan funker i her? 
    #block= [Block(96, HEIGHT- 2*block_size, block_size)] #putter dem på bunnen av skjermen
    
    objects= [*floor, Block(0, HEIGHT- 2*block_size, block_size), Block(3*block_size, HEIGHT- 4*block_size, block_size), Block(7*block_size, HEIGHT- 6*block_size, block_size)] #tar alle elemter i "floor" og splitter de opp og setter de i den nye listen?



    run= True
    while run:
        clock.tick(FPS) # runner på 60 fps
        
     
        
        for bullet in bullets:
            if bullet.y - bullet.radius < player2.hitbox[1] + player2.hitbox[3] and bullet.y + bullet.radius > player2.hitbox[1]:
                if bullet.x + bullet.radius > player2.hitbox[0] and bullet.x - bullet.radius < player2.hitbox[0] + player2.hitbox[2]:
                    player2.hit()
                    bullets.pop(bullets.index(bullet))
            
            if bullet.x < WIDTH and bullet.x > 0:
                bullet.x += bullet.vel
            else:
                bullets.pop(bullets.index(bullet))
        for bullet in bullets2:
            if bullet.y - bullet.radius < player.hitbox[1] + player.hitbox[3] and bullet.y + bullet.radius > player.hitbox[1]:
                if bullet.x + bullet.radius > player.hitbox[0] and bullet.x - bullet.radius < player.hitbox[0] + player.hitbox[2]:
                    player.hit()
                    bullets2.pop(bullets2.index(bullet))
            
            if bullet.x < WIDTH and bullet.x > 0:
                bullet.x += bullet.vel
            else:
                bullets2.pop(bullets2.index(bullet))
        

        
        #sjekker for event (f.eks bevegelse eller om bruker quitter gamet)
        for event in pg.event.get():
            if event.type== pg.QUIT:
                run= False
                break #stopper loopen
            

            
            if event.type== pg.KEYDOWN: #har den her sånn at man kan tracke jump_count- bare kan hoppe én gang
                if event.key == pg.K_RETURN:
                    if player.direction == "left":
                        facing = -1
                    else:
                        facing = 1
                    if len(bullets) < 5:
                        bullets.append(projectile(round(player.rect.x + player.rect.width // 2), round(player.rect.y + player.rect.height//2), 6, (0,0,0), facing))
                if event.key == pg.K_SPACE:
                    if player2.direction == "left":
                        facing = -1
                    else:
                        facing = 1
                    if len(bullets2) < 5:
                        bullets2.append(projectile(round(player2.rect.x + player2.rect.width // 2), round(player2.rect.y + player2.rect.height//2), 6, (0,0,0), facing))
                        
                    
                
                

                
                if event.key== pg.K_UP  and player.jump_count <2:
                    player.jump()
                    jumpingSound.play()
                    #player.jump_count= 0
                 
                if event.key== pg.K_w  and player2.jump_count <2:
                   
                    #player.jump_count= 0
                    player2.jump()
                    jumpingSound.play()
                
            
            
        player.loop(FPS)
        player2.loop(FPS)
        handle_move(player, objects, player2)
        handle_move_player2(player2,objects, player)
        

            
             
        draw(window, background, bg_image, player,player2, objects)
            
    pg.quit()
    quit() #quitter python programmet

#kaller bare main function hvis vi kaller filen direkte? 
if __name__ == "__main__":
    main(window)
    
    




